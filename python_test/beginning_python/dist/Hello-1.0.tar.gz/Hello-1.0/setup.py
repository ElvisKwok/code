#!/usr/bin/env python
# coding: utf-8 

from distutils.core import setup

setup(name = 'Hello', \
      version = '1.0', \
      description = 'A simple example', \
      author = 'Elvis', \
      py_modules = ['hello'])
